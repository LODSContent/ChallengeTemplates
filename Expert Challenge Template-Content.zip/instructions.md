<style>
    #page0 { 
        text-align:center; 
        padding:15px 20px;        
    }     
    #page0 img {display:inline;}
    #page0 h1 {
        font-weight: normal;
        border-bottom: solid 1px;
        margin:20px 0; 
        font-size:28px; 
        border-top: solid 1px; 
        padding:20px 0;        
    }
    #page0 a { font-size:18px; padding:8px 16px; color:#fff; background-color:#0091d0; }
    #page0 a:hover { text-decoration: none; background-color:rgba(0, 120, 215, .8); }
    #page0 h2 {margin-top:30px;}
    #page0 table { margin-left:auto; margin-right:auto;}  
    #page0 table tr {border:none;} 
    #page0 table td {padding:3px 5px; text-align:left;}  
    #page0 .knowledgeLink:before {margin-right:5px;}
</style>
!IMAGE[GUIDED](https://lodmanuals.blob.core.windows.net/lms/IT%20Pro%20Challenges/ITPC-logo-expert-challenge.jpg)
# Can You [Your Challenge Title]?
<br>
^KNOWLEDGE[**Challenge Overview**][overview]

>[overview]:
>
>## Understand the scenario
>
>#####Example
>You are a Microsoft&reg; 365 administrator. You need to run a pilot project to refine Office 365 management processes and practices. First, you will create pilot user accounts, assign licenses, and configure security groups by using bulk management techniques. Next, you will configure password policies, and then you will manage roles. Finally, you will configure email compliance by using Exchange Online, and then you will create a new communication site by using SharePoint Online.
>
> 
>
>## Understand your environment
>
>#####Example
>In this challenge, you will use an Office 365 E5 tenant that you created in the **Provision an Office 365 E5 Trial Subscription** setup lab. You will need the credentials and the tenant domain you created in that lab for this challenge.

===
# Task 1
 - Step one.

 - Step two.

===
# Task 2
 - Step one.

 - Step two.

===
#Challenge validation

When you are confident that you have met all the requirements for the challenge, select **Submit**. Your challenge will be evaluated automatically.

> [!ALERT] Once you select **Submit**, you will not be able to return to this challenge.

[Place your script variables here.] 
@lab.Activity(YourFirstCheck)
@lab.Activity(YourSecondCheck)


# Summary

Congratulations, you have completed the **Can You Manage Office 365?** challenge.

You have accomplished the following:

- Task one summary.
- Task two summary.

#### Summary examples - please delete the samples
- Managed Active Directory group membership by using Group Policy.
- Enumerated Active Directory group membership by using Windows PowerShell.
- Created Office 365 user accounts.
- Created an Office 365 group.


## Your feedback is important!
As you end your challenge, please take a few minutes to complete the short survey that will appear in the next window.

Alternatively, you may provide your feedback directly to <a href="mailto:challengefeedback@learnondemandsystems.com?Subject=LODS%20Challenge%20Feedback%20for%20Lab%20@lab.LabProfile.Id" target="_top">challengefeedback@learnondemandsystems.com</a>.

## Other IT Pro Challenges in this series

- GUIDED CHALLENGE: xxx

- GUIDED CHALLENGE: xxx

- ADVANCED CHALLENGE: xxx
