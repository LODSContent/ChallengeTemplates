<style>
    #page0 { 
        text-align:center; 
        padding:15px 20px;        
    }     
    #page0 img {display:inline;}
    #page0 h1 {
        font-weight: normal;
        border-bottom: solid 1px;
        margin:20px 0; 
        font-size:28px; 
        border-top: solid 1px; 
        padding:20px 0;        
    }
    #page0 a { font-size:18px; padding:8px 16px; color:#fff; background-color:#0091d0; }
    #page0 a:hover { text-decoration: none; background-color:rgba(0, 120, 215, .8); }
    #page0 h2 {margin-top:30px;}
    #page0 table { margin-left:auto; margin-right:auto;}  
    #page0 table tr {border:none;} 
    #page0 table td {padding:3px 5px; text-align:left;}  
    #page0 .knowledgeLink:before {margin-right:5px;}
</style>
!IMAGE[GUIDED](https://lodmanuals.blob.core.windows.net/lms/IT%20Pro%20Challenges/ITPC-logo-advanced-challenge.jpg)
# Can You [Your Challenge Title]?
<br>
^KNOWLEDGE[**Challenge Overview**][overview]

>[overview]:
>
>## Understand the scenario
>
>#### Example
You are a Microsoft&reg; 365 administrator. You need to manage multiple Office 365 users. First, you will create a security group. Next, you will use a comma-separated values (CSV) file to manage multiple users. Finally, you will add multiple users to a security group by using a single action.
>
>## Understand your environment
>In this challenge, you will use a virtual machine named DC01 that runs Windows&reg; Server 2019.

====
# Task heading

- Task step

- Task step

##### Examples
- Create a security group named +++Auckland Staff+++.

    >[!HINT]<details>
    ><summary>Expand this hint for guidance on creating a security group.</summary>
    >
    >Review the documentation on [creating a security group](https://docs.microsoft.com/en-us/office365/admin/email/create-edit-or-delete-a-security-group?view=o365-worldwide).
    >
    ></details>

- Add the three new users to the Auckland Staff security group by using a single action.

    >[!HINT]<details>
    ><summary>Expand this hint for guidance on adding users to a security group.</summary>
    >
    >Review the following two methods of adding multiple users to a security group: 
    >
    >- [Microsoft 365 admin center](https://docs.microsoft.com/en-us/office365/admin/create-groups/add-or-remove-members-from-groups?view=o365-worldwide)
    >
    >- [Office 365 PowerShell](https://docs.microsoft.com/en-us/powershell/module/msonline/add-msolgroupmember?view=azureadps-1.0)
    >
    ></details>

##Check your work

[Place your script variables here.] 
@lab.Activity(YourFirstCheck)

===

# Summary

Congratulations, you have completed the **Your Challenge Title** challenge.

You have accomplished the following:

- Task one summary.
- Task two summary.

#### Summary examples - please delete the samples
- Managed Active Directory group membership by using Group Policy.
- Enumerated Active Directory group membership by using Windows PowerShell.
- Created Office 365 user accounts.
- Created an Office 365 group.

##Your feedback is important!  
As you end your challenge, please take a few minutes to complete the short survey that will appear in the next window.

Alternatively, you may provide your feedback directly to <a href="mailto:challengefeedback@learnondemandsystems.com?Subject=LODS%20Challenge%20Feedback%20for%20Lab%20@lab.LabProfile.Id" target="_top">challengefeedback@learnondemandsystems.com</a>.

## Other IT Pro Challenges in this series

>This section is mandatory. Include any challenges in the series that relate to this challenge. Replace the sample titles, and delete this instruction paragraph. Leave one blank line between each challenge title.

- GUIDED CHALLENGE: xxxx
- ADVANCED CHALLENGE: Can You Create and Manage Active Directory Users and Groups?